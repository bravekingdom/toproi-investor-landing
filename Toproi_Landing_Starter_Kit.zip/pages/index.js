
import React from "react";

export default function App() {
  return (
    <div className="min-h-screen bg-white text-gray-900">
      <header className="py-8 px-6 md:px-12 text-center bg-red-50 shadow-md">
        <h1 className="text-4xl font-bold mb-2">Toproi Digital</h1>
        <p className="text-lg">Invest in Africa's Smartest Real Estate Platform</p>
      </header>

      <section className="py-12 px-6 md:px-12 max-w-4xl mx-auto text-center">
        <h2 className="text-3xl font-semibold mb-4">Why Toproi?</h2>
        <p className="text-lg mb-6">
          We're making verified land and housing investments accessible, transparent, and tech-driven for the next generation of African homeowners.
        </p>
        <div className="grid gap-6 md:grid-cols-3 text-left">
          <div>
            <h3 className="text-xl font-semibold">Strong Market</h3>
            <p>Surging housing demand across key African cities with land value rising 2–3x in under 24 months.</p>
          </div>
          <div>
            <h3 className="text-xl font-semibold">Traction</h3>
            <p>500+ early leads, MVP launched, growing partnerships with cooperatives and developers.</p>
          </div>
          <div>
            <h3 className="text-xl font-semibold">Smart Team</h3>
            <p>Lean, AI-driven operations with a founder focused on real-world impact and profitability.</p>
          </div>
        </div>
      </section>

      <section className="py-12 px-6 md:px-12 bg-gray-50">
        <h2 className="text-2xl font-semibold text-center mb-6">Get Our Investor Kit</h2>
        <div className="flex flex-col items-center space-y-4">
          <a
            href="/Toproi_Digital_Investor_Kit.zip"
            className="bg-red-600 text-white py-3 px-6 rounded-xl shadow hover:bg-red-700"
            download
          >
            📥 Download Pitch Deck & Toolkit
          </a>
          <a
            href="https://calendly.com/yourname/toproi-call"
            target="_blank"
            className="text-red-600 underline"
          >
            📅 Book a 15-min Call with the Founder
          </a>
        </div>
        <div className="mt-10 max-w-md mx-auto w-full">
          <form action="https://formsubmit.co/your@email.com" method="POST" className="space-y-4">
            <input type="hidden" name="_captcha" value="false" />
            <input type="text" name="name" required placeholder="Your Name" className="w-full p-3 border rounded" />
            <input type="email" name="email" required placeholder="Your Email" className="w-full p-3 border rounded" />
            <textarea name="message" placeholder="Your message or interest" className="w-full p-3 border rounded"></textarea>
            <button type="submit" className="bg-red-600 text-white px-5 py-2 rounded shadow hover:bg-red-700">Submit Interest</button>
          </form>
        </div>
      </section>

      <footer className="text-center text-sm text-gray-500 py-6">
        &copy; {new Date().getFullYear()} Toproi Digital. Built for investors who believe in Africa.
      </footer>
    </div>
  );
}
