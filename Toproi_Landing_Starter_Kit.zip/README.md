
# Toproi Investor Landing Page

## How to deploy

1. Create a GitHub repo and upload these files.
2. Connect the repo to Vercel: https://vercel.com/import
3. Set build command: `npm run build`
4. Set output directory: `.next`
5. Add your actual email and Calendly link in the JSX

Enjoy 🚀
